/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hadiah1teorinetbeans;

/**
 *
 * @author ADAM
 */

import javax.swing.*;
import java.awt.event.*;

public abstract class Hadiah1teoriNetbeans implements ActionListener {

    private static void buatgui(){
        Hadiah1teoriNetbeans app = new Hadiah1teoriNetbeans(){};
        
        JFrame frame = new JFrame("Hadiah teori");
        //membuat frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20, 30, 500, 350);
        frame.getContentPane().setLayout(null);
        
        //buat tombol1
        app.butt1= new JButton("Nama");
        frame.getContentPane().add(app.butt1);
        app.butt1.setBounds(20, 30, 200, 20);
        //tombol2
        app.butt2= new JButton("NIM");
        frame.getContentPane().add(app.butt2);
        app.butt2.setBounds(20, 90, 200, 20);
        //tombol3
        app.butt3= new JButton("Alamat");
        frame.getContentPane().add(app.butt3);
        app.butt3.setBounds(20, 150, 200, 20);
        
        
         app.label1 = new JLabel("");
         app.label1.setBounds(280, 30, 200,30);
         frame.getContentPane().add(app.label1);
         app.label2 = new JLabel("");
         app.label2.setBounds(280, 90, 200,30);
         frame.getContentPane().add(app.label2);
         app.label3 = new JLabel("");
         app.label3.setBounds(280, 150, 200,30);
         frame.getContentPane().add(app.label3);
         
         
         app.butt1.addActionListener(app);
         app.butt2.addActionListener(app);
         app.butt3.addActionListener(app);
         
         frame.setVisible(true);       
        
         
    }
    public void actionPerformed(ActionEvent e) {
             
        if(e.getSource()==butt1){
             
             label1.setText("William Chandra"); 
        }else if (e.getSource()==butt2){
             label2.setText("51018021");
        }else{
             label3.setText("Tanjung Bunga");  
        }
            }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable (){
            public void run(){
              buatgui();
            }
        });
    }
    JLabel label1,label2,label3;
    JButton butt1,butt2,butt3;
}

